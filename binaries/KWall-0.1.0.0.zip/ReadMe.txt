K*Wall, the Open-Source Anti-RMT-Spam Firewall
====================================================================================================

What is this?

This is an application firewall designed to do one thing: filter chat traffic for online games, 
specifically RMT spam. K*Wall watches for incoming chat packets, and then processes and filters
them using powerful deobfuscation tools and regex filtering.

K*Wall is open-source! Grab the source from Github:
https://github.com/ActiumPraetor/K-Wall
